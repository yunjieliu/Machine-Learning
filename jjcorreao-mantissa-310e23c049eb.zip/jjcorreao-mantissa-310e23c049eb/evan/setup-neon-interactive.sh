#!/bin/bash -l
#module unload python
#export PYTHONPATH="$PYTHONPATH:$EDISON_PYTHON_LIBS:/global/project/projectdirs/nervana/evan/mantissa-climate/evan/"
#:~/modules/venv/lib/python2.7/site-packages/"
#module load python_base/2.7.9
#module unload scipy/0.15.1
#module unload numpy/1.9.2
#module load matplotlib
#module load numpy/1.9.1_mkl
#module load scipy/0.14.1_mkl
module load mpi4py
module load h5py
module load neon

# models.model class for AR
export PYTHONPATH=$PYTHONPATH:/project/projectdirs/nervana/evan/mantissa-climate/evan

