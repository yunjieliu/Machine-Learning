"""
Provides neon.datasets.Dataset class for ar patches data
here it defines the data set for ARs of west america (note the image size is different between America and Europe AR patches)
"""
import logging
import numpy as np
import h5py
import os
import ipdb
import pickle
from neon.datasets.dataset import Dataset

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class AR(Dataset):
    """
    Sets up the NERSC Mantissa AR dataset.

    Attributes:
        backend (neon.backends.Backend): backend used for this data
        inputs (dict): structure housing the loaded train/test/validation
                       input data
        targets (dict): structure housing the loaded train/test/validation
                        target data

    Kwargs:
        repo_path (str, optional): where to locally host this dataset on disk
    """

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        if 'repo_path' not in kwargs:
            raise ValueError('Missing repo_path.')

        self.rootdir = os.path.join(self.repo_path)#, self.__class__.__name__)
        print ("data directory  %s" %self.rootdir)
    def initialize(self):
        pass

    def load(self, backend=None,experiment=None):
        """
        Read data from h5 file, assume it's already been created.
        Create training and test datasets from 1 or more prognostic variables.
        """
        # load data
        fname =	os.path.join(self.rootdir, self.hdf5_file)
        print ('working data file %s ' %fname)
        f = h5py.File(fname, 'r')

        one = f['AR'] 
        zero = f['Non_AR'] 
        one_date=f['AR_date']
        zero_date=f['NonAR_date']

        #get variable and train/validate/test set
        v = self.variables          # which variable to pick  
        print ('variables %s'  %v)
        a_tr = self.ar_train_size  
        n_tr = self.nonar_train_size
        print ('ar trainigng size  %d' %a_tr)
        print ('non ar training size %d' %n_tr)
        a_te = self.ar_test_size       
        n_te = self.nonar_test_size
        print ('ar test size   %d' %a_te)
        print ('non ar testing size %d' %n_te)
        
        date=dict()
        # split data into train/validate/test set and create label
        self.inputs['train'] = np.vstack((one[:a_tr,v], zero[:n_tr,v]))
        date['train'] =np.vstack((one_date[:a_tr].reshape(a_tr,1),zero_date[:n_tr].reshape(n_tr,1)))      
        # one hot encoding required for MLP 
        self.targets['train'] = np.vstack(([[1,0]] * a_tr,[[0,1]] * n_tr))

        # same with test set
        self.inputs['test'] = np.vstack((one[a_tr:a_tr+a_te,v], zero[n_tr:n_tr+n_te,v]))
        date['test'] =np.vstack((one_date[a_tr:a_tr+a_te].reshape(a_te,1),zero_date[n_tr:n_tr+n_te].reshape(n_te,1)))     
        self.targets['test'] = np.vstack(([[1,0]] * a_te, [[0,1]] * n_te))

        f.close()
        # flatten into 2d array with rows as samples
        # and columns as features
        dims = np.prod(self.inputs['train'].shape[1:]) # flattened dimension of feature 
        self.inputs['train'].shape = (a_tr+n_tr, dims)  
        self.inputs['test'].shape = (a_te+n_te, dims)   
      
        # shuffle training set
        s = range(len(self.inputs['train']))
        np.random.shuffle(s)
        self.inputs['train'] = self.inputs['train'][s]
        self.targets['train'] = self.targets['train'][s]
        date['train'] =date['train'][s]

        # [DEBUG] shuffle test to create errors
        # s = range(len(self.targets['test']))
        # np.random.shuffle(s)
        # self.targets['test'] = self.targets['test'][s]
        
        #ipdb.set_trace()
        # train and test data are randomly shuffled, here to save the randomly shuffled data index and label (for future validation)
        outfname1 = os.path.join(self.rootdir, self.outfile1) 
        pickle.dump(zip(s,self.targets['train'],date['train']),open(outfname1,"w"))
        outfname2 = os.path.join(self.rootdir, self.outfile2) 
        pickle.dump(zip(range(len(self.inputs['test'])),self.targets['test'],date['test']),open(outfname2,"w"))
        
        """
        data preprocessign is tricky, 1) normalize feature to be 0 mean and 1 std 2) normalize example to be 0 mean and 1 std
        3) sklearn l2 norm normalization 
        """
        def normalize(x):
            #Make each column mean zero, variance 1
            #x -= np.mean(x, axis=0)
            #x /= np.std(x, axis=0) # normalize each feature
             x -= np.mean(x, axis=1).reshape(x.shape[0],1)  # normalize each example
             x /= np.std(x, axis=1).reshape(x.shape[0],1)

        map(normalize, [self.inputs['train'], self.inputs['test']])
        
        #import sklearn    
        #from sklearn import preprocessing     #sklearn l2 norm  normalization
        #self.inputs['train']=preprocessing.normalize(self.inputs['train'])
        #self.inputs['test']=preprocessing.normalize(self.inputs['test'])

        # convert numpy arrays into CPUTensor backend
        self.format()
