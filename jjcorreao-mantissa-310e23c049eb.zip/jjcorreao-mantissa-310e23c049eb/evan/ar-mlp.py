__author__ = 'jcorrea'

# import sys
# #where neon and other libraries are
# sys.path.append("/project/projectdirs/nervana/jusk/experimental/site-packages/")
# neon dependencies
from neon.backends import gen_backend
from neon.layers import FCLayer, DataLayer, CostLayer
from neon.models import MLP
from neon.transforms import RectLin, Logistic, CrossEntropy
from neon.experiments import FitPredictErrorExperiment
from neon.params import val_init
import os
from data_models.ar import AR
import numpy as np
from datetime import datetime as date


import logging
logging.basicConfig(level=20)
logger = logging.getLogger()


def model_gen():
    layers = []

    layers.append(DataLayer(name = 'd0', nout=35392))

    layers.append(FCLayer(
            name = 'h0',
            nout=200,
            lrule_init={'lr_params': {'learning_rate': 0.01,
                'momentum_params': {'coef': 0.9, 'type': 'constant'}},
                'type': 'gradient_descent_momentum'},
            weight_init=val_init.UniformValGen(low=-0.1,high=0.1),
            activation=RectLin()
        )
    )

    layers.append(FCLayer(
            name = 'output',
            nout = 2,
            lrule_init={'lr_params': {'learning_rate': 0.01,
                'momentum_params': {'coef': 0.9, 'type': 'constant'}},
                'type': 'gradient_descent_momentum'},
            weight_init=val_init.UniformValGen(low=-0.1,high=0.1),
            activation = Logistic()
        )
    )

    layers.append(CostLayer(
            name = 'cost',
            ref_layer = layers[0],
            cost = CrossEntropy()
        )
    )
    model = MLP(num_epochs=10, batch_size=200, layers=layers)
    return model


basepath = "/global/project/projectdirs/nervana/evan/mantissa-climate/evan/data"
fland = os.path.join(basepath, "landmask_imgs_us.pkl")
far = os.path.join(basepath, "atmosphericriver_us+TMQ_Jun8.h5")

#get the us or eu from fland file string
country = fland.split('_')[-1].split('.')[0]

base_repo_path='/global/project/projectdirs/nervana/evan/mantissa-climate/evan/results'
repo_path = base_repo_path

dataset = AR(fland=fland, far=far, repo_path=repo_path)

experiment = FitPredictErrorExperiment(model=model_gen(), backend=gen_backend(),dataset=dataset, predictions=['train', 'test'])

experiment.run()