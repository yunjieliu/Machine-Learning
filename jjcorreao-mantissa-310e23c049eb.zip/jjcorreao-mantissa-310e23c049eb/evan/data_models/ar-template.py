__author__ = 'jcorrea'

import numpy as np
import h5py
from matplotlib import pyplot as plt
from sklearn.preprocessing import normalize
import pickle
import logging
import os

from neon.datasets.dataset import Dataset

logger = logging.getLogger(__name__)

class AR(Dataset):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

        # kwargs:   fland   -   path/to/mask
        #           far     -   path/to/dataset

        # self.data_train = self.data['data_train']
        # self.data_test = self.data['data_test']
        # self.labels_train = self.data['labels_train']
        # self.labels_test = self.data['labels_test']

        self.tr_size_ar = 2000
        self.tr_size_nar = 2000
    
        self.te_size_ar = 468
        self.te_size_nar = 1077


         #if sttring has env variables or ~ then these are expanded
        self.repo_path = os.path.expandvars(os.path.expanduser(self.repo_path))


        self.repo_path = os.path.join(self.repo_path, 'AR' )

        if not (os.path.isdir(self.repo_path)):
            os.mkdir(self.repo_path)

        self.repo_path = os.path.join(self.repo_path, '%s_%s_%s_%s_%s'%(now.month, now.day, now.year, now.hour, now.minute))

        if not (os.path.isdir(self.repo_path)):
            os.mkdir(self.repo_path)
    def get_raw_train_test(self, seed):
       

        dland = np.asarray(pickle.load(open(self.fland, 'r'))['mask']).squeeze()
        darnar = h5py.File(self.far, 'r')

        dar = np.asarray(darnar['AR']).squeeze()
        dnar = np.asarray(darnar['Non_AR']).squeeze()


        tr_ar = dar[:][:][:self.tr_size_ar]
        tr_nar = dnar[:][:][:self.tr_size_nar]

        te_ar = dar[:][:][-self.te_size_ar:]
        te_nar = dnar[:][:][-tself.e_size_nar:]

        d_tr = np.vstack(([tr_ar, tr_nar]))
        d_te = np.vstack(([te_ar, te_nar]))


         # This labels are correct
        l_tr = np.vstack(([[1,0]] * self.tr_size_ar,
                        [[0,1]] * self.tr_size_nar))

        l_te = np.vstack(([[1,0]] * self.te_size_ar,
                        [[0,1]] * self.te_size_nar))


        s = range(len(d_tr))
        d = range(len(d_te))
        np.random.RandomState(seed).shuffle(s)
        np.random.RandomState(seed).shuffle(d)

        d_tr = d_tr[s]
        d_te = d_te[d]
        l_tr = l_tr[s]
        l_te = l_te[d]

    return d_tr, d_te, l_tr, l_te



    def preprocess(self, d_tr, d_te, l_tr, l_te):
        tmq_thr = 20
        d_tr = np.multiply(d_tr, dland)
        d_te = np.multiply(d_te, dland)

        d_tr_idx = d_tr <= tmq_thr
        d_te_idx = d_te <= tmq_thr

        d_tr[ d_tr_idx ] = 0
        d_te[ d_te_idx ] = 0

        def normalize(x):
            """Make each column mean zero, variance 1"""
            x -= np.mean(x, axis=0)
            x /= np.std(x, axis=0)
            return x

        Ftr = np.asarray([normalize(d_tr[i]).flatten() for i in range(len(d_tr))])
        Fte = np.asarray([normalize(d_te[i]).flatten() for i in range(len(d_te))])
        
        self.data_train = Ftr
        self.data_test = Fte
        self.labels_train = l_tr
        self.labels_test = l_te

    def load(self, backend=None, experiment=None):
        seed = int(np.random.randint(1,25,1))

        self.preprocess(*self.get_raw_train_test(seed))
         #all the info needed to recreate the training and test like they are for this run
        
        re_creation_dict = {
                     'seed': seed,
                     'h5_file': self.far,
                     'land_mask_file' : self.fland,
                     'type': 'ar',
                     'data_path': self.data_path }

        re_creation_dict_path = os.path.join(self.repo_path, 'AR' 're_creation.pkl')


        #save the re_creation dict in same place as the inference results
        pickle.dump(re_creation_dict, open(re_creation_dict_path, 'w'))

        # Dataset.inputs

#         self.backend = None
        self.inputs = {'train': self.data_train,
                       'test': self.data_test,
                       'validation': self.data_test[:5]}

        self.targets = {'train': self.labels_train,
                        'test': self.labels_test,
                        'validation': self.labels_test[:5]}

        self.format()



