/**********************
ar_stats.c
Author: Suren Byna <SByna@lbl.gov>
Lawrence Berkeley Lab

Description:
This program goes through the output of ar_detect and 
gives the statistics of atmospheric rivers.

**********************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <math.h>

#define MAX_DAYS_AR_EVENT_LASTED 20	// Assuming max number of days an AR lasts
#define MAX_EVENTS_IN_YEAR 100		// Assuming max number of events in a year

typedef struct
{
        int year;
        int month;
        int day;
	int timestep;
        double length;
        double width;
        double end_top_lat;
        double end_top_lon;
        double end_bot_lat;
        double end_bot_lon;
	char file_name[250];
} ar_features;

typedef struct
{
	int event_id;
	int days_lasted;
	char file_name[250];
	int timestep[MAX_DAYS_AR_EVENT_LASTED];
	double end_top_lat[MAX_DAYS_AR_EVENT_LASTED];
	double end_top_lon[MAX_DAYS_AR_EVENT_LASTED];
	double end_bot_lat[MAX_DAYS_AR_EVENT_LASTED];
	double end_bot_lon[MAX_DAYS_AR_EVENT_LASTED];
	double end_mid_lat[MAX_DAYS_AR_EVENT_LASTED];
	double end_mid_lon[MAX_DAYS_AR_EVENT_LASTED];
	double end_geo_dist[MAX_DAYS_AR_EVENT_LASTED];
	int month[MAX_DAYS_AR_EVENT_LASTED];
	int day[MAX_DAYS_AR_EVENT_LASTED];
	float length[MAX_DAYS_AR_EVENT_LASTED];
	float width[MAX_DAYS_AR_EVENT_LASTED];
} ar_event;

typedef struct
{
	int year;
	int count;
	int month_cnt[12];
	ar_event arevnt[MAX_EVENTS_IN_YEAR];
} year_cnt;

//get_num_ar_events: returns the number of ar events, i.e. number of lines
//in an ar output file
int get_num_ar_events (char *ifile)
{
	FILE* fptr;
	int c, count = 0;
	
	fptr = fopen(ifile, "r");
	
	if(fptr == NULL)
	{
		printf("AR events output file does not exist!\n");
		return -1;
	}

	do {
		c = fgetc(fptr);
		if (c == '\n')
		{
			count++;
		}
	} while (c != EOF);
	fclose(fptr);
	return count;
}

/**************
findAll and split functions splits a string and ouputs tokens
Source : http://www.cplusplus.com/forum/general/51204/
**************/
int findAll(std::string str, char delim)
{
	int size = 0, temp = 0, pos = 0;
	while ( (temp = str.find(delim, pos) ) > -1)
	{
		pos = 1 + temp; size++;
	}
	return size + 1;
}

std::string* split(std::string str, char delim, int& outSize)
{
	outSize = findAll(str, delim);
	if (outSize == 0)
		return NULL;
	std::string* out = new std::string[outSize];
	for (int index = 0, start = 0, find = 0; index < outSize; index++)
	{
		find = str.find(delim, start);
		if (find < 0 || find < start)
		{
			out[index] = str.substr(start);
			break;
		}
		else
			out[index] = str.substr(start, find - start);
		start = find + 1;
	}
	return out;
}
/**********
End of split string related functions
*********/

//read_ar_features function reads all the ar_features information from file
//returns ar_features array pointer
int read_ar_features (char *ifile, ar_features *arf, int ar_count)
{
	std::ifstream ins;
	ins.open (ifile);
	std::string line;
	int num_tokens;

	for (int i = 0; i < ar_count; i++)
	{
		getline (ins, line);
		std::string* vals = split(line, '\t', num_tokens);
		if (num_tokens != 12)
		{
			printf ("ERROR: Didn't read the correct number of tokens, in line: %d \n", i+1);
			return -1;
		}
		arf[i].year = atoi (vals[0].c_str());			// Year
		arf[i].month = atoi (vals[1].c_str());			// Month
		arf[i].day = atoi (vals[2].c_str());			// Day
		arf[i].timestep = atoi (vals[3].c_str());		// Time step in the netcdf file
		arf[i].length = atof (vals[4].c_str());			// Length of an AR
		arf[i].width = atof (vals[5].c_str());			// Width of an AR
		arf[i].end_top_lat = atof (vals[6].c_str());		// Top latitude
		arf[i].end_top_lon = atof (vals[7].c_str());		// Top longitude
		arf[i].end_bot_lat = atof (vals[8].c_str());		// Bottom latitude
		arf[i].end_bot_lon = atof (vals[9].c_str());		// Bottom longitude
		// arf[i].file_name = vals[11].c_str();
		strcpy (arf[i].file_name, vals[11].c_str());		// netcdf file name

#ifdef DEBUG
		printf ("year: %d month: %d day: %d timestep: %d length: %.3f width: %.3f top_lat: %.3f top_lon: %.3f bot_lat: %.3f bot_lon: %.3f file_name: %s \n", \
			arf[i].year, arf[i].month, arf[i].day, arf[i].timestep, \
			arf[i].length, arf[i].width,	 \
			arf[i].end_top_lat, arf[i].end_top_lon, \
			arf[i].end_bot_lat, arf[i].end_bot_lon, arf[i], arf[i].file_name);
#endif
	}
	return 1;
}
//End of read_ar_features function

//get_num_years function: returns the number of discrete years in the output
int get_num_years (ar_features *arf, int num_events)
{
	int cur_yr = arf[0].year;
	int num_yrs = 1;

	for (int i = 1; i < num_events; i++)
	{
		// Assuming that all dates are sorted
		if (cur_yr != arf[i].year)
		{
			num_yrs++;
		}
		cur_yr = arf[i].year;
	}
	return num_yrs;
}

// day_num_in_year function: returns the number of a day in a calendar year
int day_num_in_year (int year, int month, int day)
{
	int ndays [12] = {31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365};
	int ldays [12] = {31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366};
	int *norl;

	int day_id = 0;
	if  (year % 4 == 0)
	{
		norl = ldays;
	}
	else
	{
		norl = ndays;
	}

	if (month > 1)
	{
		day_id = norl[month-2];
	}
	day_id += day;

#ifdef DEBUG
	printf ("day_id: %d\n", day_id);
#endif
	return day_id;
}

// Calculate geodesic distance between two lat, long pairs
// from http://www.geodatasource.com/developers/c
// from http://osiris.tuwien.ac.at/~wgarn/gis-gps/latlong.html
// from http://www.codeproject.com/KB/cpp/Distancecplusplus.aspx
double calc_geodesic_distance (double lat1, double lon1, double lat2, double lon2)
{
        double R = 6371;
        double PI = 4.0 * atan(1.0);

        //main code inside the class
        double dlat1 = lat1 * (PI/180);

        double dlon1 = lon1 * (PI/180);
        double dlat2 = lat2 * (PI/180);
        double dlon2 = lon2 * (PI/180);

        double dLon = dlon1 - dlon2;
        double dLat = dlat1 - dlat2;

        double aHarv =  pow (sin (dLat/2.0), 2.0) +     \
                        cos (dlat1) * cos (dlat2) * pow (sin (dLon/2), 2);

        double cHarv = 2 * atan2 (sqrt(aHarv), sqrt(1.0 - aHarv));

        double distance = R*cHarv;

        return distance;
}


// mid_point function
// The function calculates geodesic midpoint between two lat lon coordinates
// Source conveted from C#: http://stackoverflow.com/questions/4164830/geographic-midpoint-between-two-coordinates

void geodesic_midpoint (double lat1, double lon1, double lat2, double lon2, double *mid_lat, double *mid_lon)
{
	double PI = 4.0 * atan(1.0);
	double dLon = (lon2 - lon1) * (PI/180);		// Convert (lon2-lon1) to radians
	double dLat1 = lat1 * (PI/180);		// Convert lat1 to radians
	double dLat2 = lat2 * (PI/180);		// Convert lat2 to radians
	double dLon1 = lon1 * (PI/180);		// Convert lon1 to radians

	double Bx = cos(dLat2) * cos(dLon);
	double By = cos(dLat2) * sin(dLon);

	*mid_lat = atan2( (sin(dLat1)+sin(dLat2)), (sqrt((cos(dLat1)+Bx)*(cos(dLat1)+Bx)+By*By)) );
        *mid_lon = dLon1 + atan2(By, (cos(dLat1)+Bx));

	*mid_lat = *mid_lat * (180/PI);
	*mid_lon = *mid_lon * (180/PI);
}

// calculate moisture flux at mid-point
//
double flux_at_midpoint (double mid_lat, double mid_lon, char* prw_file_name)
{
	char prefix[5] = "prw";
	char rem_str[100];

	// rem_str = strstr (prw_file_name, prefix);
	strcpy (rem_str, prw_file_name+3);

	printf ("Remaining file name: %s \n", rem_str);

	return 0.0;
}


// count_events function
// The function that counts the events
// 
void count_events (ar_features *arf, year_cnt *yc, int num_yrs, int num_events)
{
	int cur_year, prev_year;
	int prev_day_num, cur_day_num;
	
	for (int i = 0; i < num_yrs; i++)
	{
		yc[i].count = 0;
		for (int m = 0; m < 12; m++)
		{
			yc[i].month_cnt[m] = 0;
		}
	}

	// Copy the first AR event information
	prev_day_num = day_num_in_year (arf[0].year, arf[0].month, arf[0].day);
	prev_year = arf[0].year;
	int year_cnt = 0;
	yc[year_cnt].year = prev_year;
	yc[year_cnt].count++;
	int temp_cnt = yc[year_cnt].count;
	int temp_cnt2;
	double temp_mid_lat, temp_mid_lon;
	double flux_mp;

	yc[year_cnt].arevnt[temp_cnt].event_id = temp_cnt;
	yc[year_cnt].arevnt[temp_cnt].days_lasted = temp_cnt;
	strcpy (yc[year_cnt].arevnt[temp_cnt].file_name, arf[0].file_name);
	yc[year_cnt].arevnt[temp_cnt].timestep[temp_cnt] = arf[0].timestep;
	yc[year_cnt].arevnt[temp_cnt].end_top_lat[temp_cnt] = arf[0].end_top_lat;
	yc[year_cnt].arevnt[temp_cnt].end_top_lon[temp_cnt] = arf[0].end_top_lon;
	yc[year_cnt].arevnt[temp_cnt].end_bot_lat[temp_cnt] = arf[0].end_bot_lat;
	yc[year_cnt].arevnt[temp_cnt].end_bot_lon[temp_cnt] = arf[0].end_bot_lon;
	geodesic_midpoint (arf[0].end_top_lat, arf[0].end_top_lon,      \
			   arf[0].end_bot_lat, arf[0].end_bot_lon,      \
			   &temp_mid_lat, &temp_mid_lon);
	yc[year_cnt].arevnt[temp_cnt].end_mid_lat[temp_cnt] = temp_mid_lat;
	yc[year_cnt].arevnt[temp_cnt].end_mid_lon[temp_cnt] = temp_mid_lon;

	// flux_mp = flux_at_midpoint (temp_mid_lat, temp_mid_lon, arf[0].file_name);

	yc[year_cnt].arevnt[temp_cnt].end_geo_dist[temp_cnt] = calc_geodesic_distance (arf[0].end_top_lat, arf[0].end_top_lon,	\
										      arf[0].end_bot_lat, arf[0].end_bot_lon);
	yc[year_cnt].arevnt[temp_cnt].month[temp_cnt] = arf[0].month;
	yc[year_cnt].arevnt[temp_cnt].day[temp_cnt] = arf[0].day;
	yc[year_cnt].arevnt[temp_cnt].length[temp_cnt] = arf[0].length;
	yc[year_cnt].arevnt[temp_cnt].width[temp_cnt] = arf[0].width;

	// Loop through from event 1 (event zero is already read) to the end
	for (int i = 1; i < num_events; i++)
	{
		// Check for any duplicate entries; Do not exit, but report all the duplicates at once
		if ((arf[i].year == arf[i-1].year) && (arf[i].month == arf[i-1].month) && (arf[i].day == arf[i-1].day))
		{
			printf ("ERROR: Duplicate AR event found in line %d, year: %d mon: %d day: %d\n", i, arf[i].year, arf[i].month, arf[i].day);
		}

		// Check if any day or month values are either zero or invalid!!
		if ((arf[i].year == 0) || (arf[i].month == 0) || (arf[i].month > 12) || (arf[i].day == 0) || (arf[i].day > 31))
		{
			printf ("ERROR: Date is invalid in line %d, year: %d mon: %d day: %d\n", i, arf[i].year, arf[i].month, arf[i].day);
		}

		cur_day_num = day_num_in_year (arf[i].year, arf[i].month, arf[i].day);
		cur_year = arf[i].year;

		if (cur_year == prev_year)
		{
			if ((cur_day_num - prev_day_num) > 2)
			{
				yc[year_cnt].count++;
				temp_cnt = yc[year_cnt].count;
				yc[year_cnt].arevnt[temp_cnt].event_id = temp_cnt;
				yc[year_cnt].arevnt[temp_cnt].days_lasted = 1;
				strcpy (yc[year_cnt].arevnt[temp_cnt].file_name, arf[i].file_name);
				yc[year_cnt].arevnt[temp_cnt].timestep[1] = arf[i].timestep;
				yc[year_cnt].arevnt[temp_cnt].end_top_lat[1] = arf[i].end_top_lat;
				yc[year_cnt].arevnt[temp_cnt].end_top_lon[1] = arf[i].end_top_lon;
				yc[year_cnt].arevnt[temp_cnt].end_bot_lat[1] = arf[i].end_bot_lat;
				yc[year_cnt].arevnt[temp_cnt].end_bot_lon[1] = arf[i].end_bot_lon;
				geodesic_midpoint (arf[i].end_top_lat, arf[i].end_top_lon,	\
						   arf[i].end_bot_lat, arf[i].end_bot_lon,	\
						    &temp_mid_lat, &temp_mid_lon);
				yc[year_cnt].arevnt[temp_cnt].end_mid_lat[1] = temp_mid_lat;
				yc[year_cnt].arevnt[temp_cnt].end_mid_lon[1] = temp_mid_lon;
				yc[year_cnt].arevnt[temp_cnt].end_geo_dist[1] = calc_geodesic_distance (arf[i].end_top_lat, arf[i].end_top_lon,  \
													arf[i].end_bot_lat, arf[i].end_bot_lon);
				yc[year_cnt].arevnt[temp_cnt].month[1] = arf[i].month;
				yc[year_cnt].arevnt[temp_cnt].day[1] = arf[i].day;
				yc[year_cnt].arevnt[temp_cnt].length[1] = arf[i].length;
				yc[year_cnt].arevnt[temp_cnt].width[1] = arf[i].width;
#ifdef DEBUG
				printf ("prev_day_num: %d cur_day_num: %d count: %d \n", \
					prev_day_num, cur_day_num, temp_cnt);
#endif
			}
			else
			{
				yc[year_cnt].arevnt[temp_cnt].days_lasted++;
				temp_cnt2 = yc[year_cnt].arevnt[temp_cnt].days_lasted;
				strcpy (yc[year_cnt].arevnt[temp_cnt].file_name, arf[i].file_name);
				yc[year_cnt].arevnt[temp_cnt].timestep[temp_cnt2] = arf[i].timestep;
				yc[year_cnt].arevnt[temp_cnt].end_top_lat[temp_cnt2] = arf[i].end_top_lat;
				yc[year_cnt].arevnt[temp_cnt].end_top_lon[temp_cnt2] = arf[i].end_top_lon;
				yc[year_cnt].arevnt[temp_cnt].end_bot_lat[temp_cnt2] = arf[i].end_bot_lat;
				yc[year_cnt].arevnt[temp_cnt].end_bot_lon[temp_cnt2] = arf[i].end_bot_lon;
				geodesic_midpoint (arf[i].end_top_lat, arf[i].end_top_lon,      \
                                                   arf[i].end_bot_lat, arf[i].end_bot_lon,      \
						   &temp_mid_lat, &temp_mid_lon);
				yc[year_cnt].arevnt[temp_cnt].end_mid_lat[temp_cnt2] = temp_mid_lat;
				yc[year_cnt].arevnt[temp_cnt].end_mid_lon[temp_cnt2] = temp_mid_lon;
				yc[year_cnt].arevnt[temp_cnt].end_geo_dist[temp_cnt2] = calc_geodesic_distance (arf[i].end_top_lat, arf[i].end_top_lon,  \
														arf[i].end_bot_lat, arf[i].end_bot_lon);
				yc[year_cnt].arevnt[temp_cnt].month[temp_cnt2] = arf[i].month;
				yc[year_cnt].arevnt[temp_cnt].day[temp_cnt2] = arf[i].day;
				yc[year_cnt].arevnt[temp_cnt].length[temp_cnt2] = arf[i].length;
				yc[year_cnt].arevnt[temp_cnt].width[temp_cnt2] = arf[i].width;
			}
		}
		else
		{
			year_cnt++;
			yc[year_cnt].year = cur_year;
			yc[year_cnt].count++;
			temp_cnt = yc[year_cnt].count;
			yc[year_cnt].arevnt[temp_cnt].event_id = temp_cnt;
			yc[year_cnt].arevnt[temp_cnt].days_lasted = temp_cnt;
			strcpy (yc[year_cnt].arevnt[temp_cnt].file_name, arf[i].file_name);
			yc[year_cnt].arevnt[temp_cnt].timestep[temp_cnt] = arf[i].timestep;
			yc[year_cnt].arevnt[temp_cnt].end_top_lat[temp_cnt] = arf[i].end_top_lat;
			yc[year_cnt].arevnt[temp_cnt].end_top_lon[temp_cnt] = arf[i].end_top_lon;
			yc[year_cnt].arevnt[temp_cnt].end_bot_lat[temp_cnt] = arf[i].end_bot_lat;
			yc[year_cnt].arevnt[temp_cnt].end_bot_lon[temp_cnt] = arf[i].end_bot_lon;
			geodesic_midpoint (arf[i].end_top_lat, arf[i].end_top_lon,      \
					   arf[i].end_bot_lat, arf[i].end_bot_lon,      \
					   &temp_mid_lat, &temp_mid_lon);
			yc[year_cnt].arevnt[temp_cnt].end_mid_lat[temp_cnt] = temp_mid_lat;
			yc[year_cnt].arevnt[temp_cnt].end_mid_lon[temp_cnt] = temp_mid_lon;
			yc[year_cnt].arevnt[temp_cnt].end_geo_dist[temp_cnt] = calc_geodesic_distance (arf[i].end_top_lat, arf[i].end_top_lon,  \
												       arf[i].end_bot_lat, arf[i].end_bot_lon);
			yc[year_cnt].arevnt[temp_cnt].month[temp_cnt] = arf[i].month;
			yc[year_cnt].arevnt[temp_cnt].day[temp_cnt] = arf[i].day;
			yc[year_cnt].arevnt[temp_cnt].length[temp_cnt] = arf[i].length;
			yc[year_cnt].arevnt[temp_cnt].width[temp_cnt] = arf[i].width;
		}
		prev_year = cur_year;
		prev_day_num = cur_day_num;
	}
}

int dump_stats (year_cnt *ycnt, int num_yrs, char *stats_file)
{
	FILE *stats_file_t;
	stats_file_t = fopen (stats_file, "a");

	if (stats_file_t == NULL)
	{
		printf ("ERROR: in opening file to dump statistics \n");
		return -1;
	}

	fprintf (stats_file_t, "Yearly Statistics\n");
	fprintf (stats_file_t, "====================\n");
	fprintf (stats_file_t, "Year \t # of AR events\n");

	for (int i = 0; i < num_yrs; i++)
	{
		fprintf (stats_file_t, "%d  ---> %d\n", ycnt[i].year, ycnt[i].count);
	}

	fprintf (stats_file_t, "\nDetailed Information of AR Events\n");
	fprintf (stats_file_t, "==================================\n");
	for (int i = 0; i < num_yrs; i++)
	{
		fprintf (stats_file_t, "\n\nYear: %d - # of AR Events: %d \n", ycnt[i].year, ycnt[i].count);
		for (int j = 1; j < ycnt[i].count+1; j++)
		{
			fprintf (stats_file_t, "\n  Event id: %d, Number of days lasted: %d File name: %s\n", \
				   ycnt[i].arevnt[j].event_id, 			\
				   ycnt[i].arevnt[j].days_lasted, 		\
				   ycnt[i].arevnt[j].file_name);
			fprintf (stats_file_t, "    ID   Date     Time step        Landfall (between)                 Length      Width          Width at Landfall      Midpoint\n");
			fprintf (stats_file_t, "    ---------------------------------------------------------------------------------------------------------------------------- \n");
			for (int k = 1; k < ycnt[i].arevnt[j].days_lasted+1; k++)
			{
				fprintf (stats_file_t, "    %d. (%d-%d-%d):   %d  (%.3f, %.3f) and (%.3f, %.3f)     %.3f     %.3f       %.3f                (%.3f, %.3f)\n", \
					k, ycnt[i].arevnt[j].month[k],		   \
					ycnt[i].arevnt[j].day[k],		   \
					ycnt[i].year,			   	   \
					ycnt[i].arevnt[j].timestep[k],		   \
					ycnt[i].arevnt[j].end_top_lat[k], 	   \
					ycnt[i].arevnt[j].end_top_lon[k], 	   \
					ycnt[i].arevnt[j].end_bot_lat[k], 	   \
					ycnt[i].arevnt[j].end_bot_lon[k],	   \
					ycnt[i].arevnt[j].length[k],		   \
					ycnt[i].arevnt[j].width[k],		   \
					ycnt[i].arevnt[j].end_geo_dist[k],		   \
					ycnt[i].arevnt[j].end_mid_lat[k], 	   \
					ycnt[i].arevnt[j].end_mid_lon[k]);
			}
		}
		fprintf (stats_file_t, "\n ****************** ");
	}

	fclose (stats_file_t);
	return 1;
}

/*******
	count_events_in_file function counts the number of AR events in a file
	Output format needed:
		* How many events per year
		* Details of each event
		*
******/
void count_events_in_file (char *ar_ofile, char *stats_ofile)
{
	int num_events = get_num_ar_events (ar_ofile);

	// Find the number of events in the given file
	if (num_events <= 0)
	{
		printf ("ERROR: Either there are no AR events in the file or the file does not exist! Check the input file \n");
		exit (1);
	}
	printf ("Total number of events: %d \n", num_events);

	// Allocate an array for reading ar_features
	ar_features *arf = (ar_features *) malloc (num_events * sizeof (ar_features));
	if (arf == NULL)
	{
		printf ("ERROR: in allocating the ar_features array \n");
		exit (1);
	}

	// Read the ar_features of each event in the file
	int retval = read_ar_features (ar_ofile, arf, num_events);
	if (retval < 0)
	{
		printf ("ERROR: in read_ar_features \n");
		free (arf);
		exit (1);
	}

	// get the number of years in the file
	int num_yrs;
	num_yrs = get_num_years (arf, num_events);

	printf ("Number of years: %d \n", num_yrs);
#ifdef DEBUG
	printf ("Number of years: %d \n", num_yrs);
#endif

	// Allocate memory for yearly statistics
	year_cnt *ycnt = (year_cnt *) malloc (num_yrs * sizeof (year_cnt));
	
	// Count yearly statistics
	count_events (arf, ycnt, num_yrs, num_events);

	retval = dump_stats (ycnt, num_yrs, stats_ofile);
	
	if (retval < 0)
	{
		printf ("ERROR: in dumping statistics \n");
		free (arf);
		free (ycnt);
		exit (1);
	}

	free (arf);
	free (ycnt);
}
