
import numpy as np
import os
import pickle
import h5py
import glob

data_path = "/project/projectdirs/mantissa/climate/Yunjie/ar_patch/new"

landmask_file = os.path.join(data_path, "landmask_imgs.pkl")
landmask_data = np.array(pickle.load(open(landmask_file, 'r'))['mask'])

dimX = 158
dimY = 224
ndim = 31

h5f = h5py.File(os.path.join(data_path, "AR_data.h5"), "w")
h5f_AR_data = h5f.create_dataset("AR_data",(ndim,dimX,dimY), dtype=np.float32)
h5f_ifAR = h5f_AR_data.create_dataset("ifAR",(ndim,dimX,dimY), dtype=np.float32)
h5f_key_data = h5f_AR_data.create_dataset("key",(ndim,dimX,dimY), dtype=np.float32)

# for data_file in glob.glob(os.path.join(data_path, "*_nonar_*.pkl")):
for data_file in glob.glob(os.path.join(data_path, "*_*_*.pkl")):
    data = np.array(pickle.load(open(data_file,'r'))['TMQ'])

    for n in range(0, data.shape[0]):
        for i in range(0, data.shape[1]):
            for j in range(0, data.shape[2]):
                if "nonar" in data_file:

                    if data[n,i,j] >= 20 and landmask_data[n,i,j] != 0:
                        h5f_AR_data[n,i,j] = data[n,i,j]
                        h5f_key_data[n,i,j] = 1
                        h5f_key_data = data[n,i,j]
                        print("%s: %s/%s" % (data_file,n, data.shape[0]))
                    else:
                        h5f_AR_data[n,i,j] = data[n,i,j]
                        h5f_ifAR[n,i,j] = 0
                        h5f_key_data = 0
                        print("%s: %s/%s" % (data_file,n, data.shape[0]))
                else:
                    if data[n,i,j] >= 20 and landmask_data[n,i,j] != 0:
                        h5f_AR_data[n,i,j] = data[n,i,j]
                        h5f_key_data[n,i,j] = 0
                        h5f_key_data = data[n,i,j]
                        print("%s: %s/%s" % (data_file,n, data.shape[0]))
                    else:
                        h5f_AR_data[n,i,j] = data[n,i,j]
                        h5f_ifAR[n,i,j] = 0
                        h5f_key_data = 0
                        print("%s: %s/%s" % (data_file,n, data.shape[0]))
