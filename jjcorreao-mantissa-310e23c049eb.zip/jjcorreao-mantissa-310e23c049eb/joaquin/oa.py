__author__ = 'jcorrea'

# import pandas as pd
import os
#
path = "/Users/DOE6903584/Documents/OAR"
# filename = "ref_pubs_14"
# filename1 = "ref_pubs_15.6"
filename1 = "removed"
# file = os.path.join(path, filename)
file1 = os.path.join(path, filename1)
#
# data_names = ["firstname", "lastname", "office_label", "sci_cat_label", "refereed_pubs"]
#
# data_dtype = {"firstname": str,
#               "lastname": str,
#               "office_label": str,
#               "sci_cat_label": str,
#               "refereed_pubs": str}
#
# data = pd.read_csv(file, sep="|", names=data_names, dtype=data_dtype)
# data1 = pd.read_csv(file1, sep="\&#013", names=["data"], dtype={"data": str}, skip_blank_lines=False)

#M
#N
#O
#P
#Q
#R
#S
#T
#U
#V
#W
#X
#Y
#Z

import re

#DuckYoung|Kim|BES|Materials Science|
f = open(file1, 'r')

# line = "Cats are smarter than dogs"
# line = "#DuckYoung|Kim|BES|Materials Science|"

# r'(.*) are (.*?) .*'
# r'#*|*|*|*|'

# matchObj = re.match( r'#(.*)|(.*)|(.*)|(.*)|', line, re.M|re.I)
# if matchObj:
#    print "match --> matchObj.group() : ", matchObj.group()
# else:
#    print "No match!!"

# searchObj = re.search( r'#(.*)|(.*)|(.*)|(.*)|', line, re.M|re.I)
# if searchObj:
#    print "search --> searchObj.group() : ", searchObj.group()
# else:
#    print "Nothing found!!"
#
# uu = os.path.join(path, "removed")
# jj = os.path.join(path, "final")

uu = os.path.join(path, "removed2")
jj = os.path.join(path, "final2")

u = open(uu, 'w')
j = open(jj, 'w')
#
# match = False
# while not searchObj:
#     line = f.readline()
#     searchObj = re.search( r'#(.*)|(.*)|(.*)|(.*)|', line, re.M|re.I)

def file_len(full_path):
  """ Count number of lines in a file."""
  f = open(full_path)
  nr_of_lines = sum(1 for line in f)
  f.close()
  return nr_of_lines

# combos = [r'^#M(.*)|(.*)|(.*)|(.*)|$',
#           r'^#N(.*)|(.*)|(.*)|(.*)|$',
#           r'^#O(.*)|(.*)|(.*)|(.*)|$',
#           r'^#P(.*)|(.*)|(.*)|(.*)|$',
#           r'^#Q(.*)|(.*)|(.*)|(.*)|$',
#           r'^#R(.*)|(.*)|(.*)|(.*)|$',
#           r'^#S(.*)|(.*)|(.*)|(.*)|$',
#           r'^#T(.*)|(.*)|(.*)|(.*)|$',
#           r'^#U(.*)|(.*)|(.*)|(.*)|$',
#           r'^#V(.*)|(.*)|(.*)|(.*)|$',
#           r'^#X(.*)|(.*)|(.*)|(.*)|$',
#           r'^#Y(.*)|(.*)|(.*)|(.*)|$',
#           r'^#Z(.*)|(.*)|(.*)|(.*)|$']

# c = 0

# for ii in range(0, file_len(file1)):
#     # line = f.readline()
#     for idx, com in enumerate(combos):
#         line = f.readline()
#         searchObj = re.search(com, line, re.M|re.I)
#         if searchObj.group(1) is not None:
#             # print(searchObj.group())
#             # S = True
#             while line != re.search(combos[idx+1], line, re.M|re.I).group(1):
#                 # if comp == searchObj.group(1):
#                 # hola = "%s \n" % (searchObj.group())
#                 hola = "%s \n" % (line)
#                 # u.write(hola)
#                 line = f.readline()
#                 # else:
#                 #     S = False
#
#                 # c = c + 1
#                 # print(hola)

import itertools

# liss = ["in press",
#         "press",
#         "2012",
#         "2011",
#         "2010",
#         "submitted",
#         "conference"]

["Results from this pilot have been presented at joint NIH/DOE meetings related to HPC's role in the NIH '"Big Data 2 Knowledge"' and at National Lab Day where several NIH/DOE discussion took place. http://energy.gov/articles/secretary-moniz-host-national-laboratory-day-capitol-hill",


 "Davis, G; Marino, S.; Marrs, CF; Gilsdorf, JR; Dawid, S; Kirschner, D. Phase Variation and Host Immunity Against High Molecular Weight (HMW) Adhesins Shape Population Dynamics of Nontypeable Haemophilus influenzae Within Human Hosts (in press) J. Theor. Biol.  2014.",

 "Linderman, JL, Hunt A, Marino, S, Fallahi-Sichani, M, Kirschner, D. Tuneable resolution as a approach to study multi-scale, multi-organ models in systems biology WIRES Systems Biology and Medicine, 2014 doi: 10.1002/wsbm.1270",

 "Linderman JJ, Kirschner DE. In silico models of M. tuberculosis infection provide a route to new therapies, Drug Discov Today: Dis Model (2014), http://dx.doi.org/10.1016/j.ddmod.2014.02.006.",

 "Gong, C, Linderman, JL and Kirschner, D. Harnessing the heterogeneity of T cell differentiation fate to fine-tune generation of effector and memory T cells Frontiers in T cell Biology, published 2014."]

liss = ["in press",
        "press",
        "2012",
        "2011",
        "2010",
        "submitted",
        "conference"]

# lis = [ map(''.join, itertools.product(*zip(liss.upper(), liss.lower())))]

lisso = []


for item in liss:
    for iitem in map(''.join, itertools.product(*zip(item.upper(), item.lower()))):
        lisso.append(iitem)
        # print(iitem)

for ii in range(0, file_len(file1)):
    # line = f.readline()
    for idx, li in enumerate(lisso):
        line = f.readline()
        searchObj = re.search(li, line, re.M|re.I)
        # try:
        if searchObj is not None:
        # if len(searchObj.group()) == 0:
        # if isinstance(searchObj.group):
            # print(searchObj.group())
            # print(line)
            u.write(line)
            # S = True
            # while line != re.search(combos[idx+1], line, re.M|re.I).group(1):
                # if comp == searchObj.group(1):
                # hola = "%s \n" % (searchObj.group())
                # hola = "%s \n" % (line)
                # u.write(hola)
                # line = f.readline()
                # else:
                #     S = False
                #
                # c = c + 1
                # print(hola)
        else:
            j.write(line)

    print("%s/%s" % (ii, file_len(file1)))

u.close()
j.close()
#
# s = 'Fox'
# map(''.join, itertools.product(*zip(s.upper(), s.lower())))

# print("hello")
# f.close()
# if not a:
#   print "List is empty"
#
# while temperature > 112: # first while loop code
#     print(temperature)
#     temperature = temperature - 1
#
# print('The tea is cool enough.')