This directory contains some sample neon experiment configuration files.

The general process for running these is to first install neon into your
system from the top-level directory via:

    make install

Which should yield an executable in your system path named `neon`

Then just issue:

    neon whatever_example.yaml
