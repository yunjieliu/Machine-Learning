"""
Read Sang's hurricane files and plot them
"""
import numpy as np
import pandas
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid
import cPickle as pickle
import glob
import os
import ipdb

class Hurricanes(object):

    def __init__(self, root=None):
        if root is None:
            root = os.path.join(os.path.expanduser('~'), 'nervana/mantissa/hurricane')
        self.root = root
            
        self.imgs = glob.glob(os.path.join(root, '*_imgs.pkl'))

        self.vars = (u'TMQ', u'V850', u'PSL', u'U850',
                     u'T500', u'UBOT', u'T200', u'VBOT')

    def load(self, year, month):
        fname = 'hurricanes-%d-%02d' % (year, month)
        
        self.p = pandas.read_pickle(os.path.join(self.root, fname + '_imgs.pkl'))          
        self.l = pandas.read_pickle(os.path.join(self.root, fname + '_list.pkl'))

    def plot(self, rows=20):
        dim = self.p[self.vars[0]][0].shape[0] 
        cols = len(self.vars) 
        nrows = len(self.p[self.vars[0]])
        if rows >= nrows: rows = nrows

        # normalize
        mean = np.zeros(cols)
        std = np.zeros(cols)
        for i, v in zip(range(cols), self.vars):
            mean[i] = np.mean(self.p[v])
            std[i] = np.std(self.p[v])

        plt.figure(1, figsize=(10, 10))
        plt.clf()

        im = np.empty((rows*(dim+1)+1, dim))

        for v,c in zip(self.vars, range(cols)):
            im.fill(0)

            r = 1            
            for i in range(rows):
                im[r:r+dim] = (self.p[v][i] - mean[c]) / std[c]
                r += dim + 1

            plt.subplot(1, cols, c+1)
            plt.imshow(im)
            plt.xticks([])
            plt.yticks([])
            
        plt.subplots_adjust(left=0.05, right=0.05, botton=0.05,
                            top=0.95, wspace=0.01)

def main():
    h = Hurricanes()
    h.load(1979, 1)
    # h.plot()

if __name__ == '__main__':
    main()
        
                      
            
        
