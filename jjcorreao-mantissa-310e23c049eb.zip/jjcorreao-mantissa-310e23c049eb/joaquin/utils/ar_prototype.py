#
#
import logging
import numpy as np
import h5py
import os
# import neon
#
from neon.datasets.dataset import Dataset
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

import numpy as np
from sklearn.preprocessing import normalize


#
class AR(Dataset):

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        # if 'repo_path' not in kwargs:
        #     raise ValueError('Missing repo_path.')

        self.rootdir = os.path.join(self.repo_path, self.__class__.__name__)
        # self.rootdir = self.repo_path

    def load(self):

        f = h5py.File(self.filess)
        # f = h5py.File(os.path.join(self.rootdir, self.hdf5_file), 'r')

        AR = f['AR']
        nAR = f['Non_AR']


        tr = self.training_size
        te = self.test_size

        AR_data = np.vstack(AR.value)
        nAR_data = np.vstack(nAR.value)

        # labels = np.array(['AR', 'nAR'],dtype='|S3')

        # 35392 comes from shape np.zeros([158,224]).flatten()

        AR_train = AR_data[:tr]
        nAR_train = nAR_data[:tr]

        # AR_test = AR_data[tr:tr+te]
        # nAR_test = nAR_data[tr:tr+te]
        AR_test = AR_data[tr:tr+te]
        nAR_test = nAR_data[tr:tr+te]


        AR_flat_train = np.zeros([AR_train.shape[0], 35392])
        nAR_flat_train = np.zeros([nAR_train.shape[0], 35392])
        AR_flat_test = np.zeros([AR_test.shape[0], 35392])
        nAR_flat_test = np.zeros([nAR_test.shape[0], 35392])

        for ij in range(0,AR_train.shape[0]):
            AR_flat_train[ij] = AR_train[ij].flatten()
            nAR_flat_train[ij] = nAR_train[ij].flatten()
            # print(ij)

        labels_train = np.zeros([AR_test.shape[0], 2])
        labels_test = np.zeros([AR_test.shape[0], 2])

        for ij in range(0,AR_test.shape[0]):
            AR_flat_test[ij] = AR_test[ij].flatten()
            nAR_flat_test[ij] = nAR_test[ij].flatten()
            labels_train[ij][0] = 1
            labels_test[ij][1] = 1

        labels_trainn = np.hstack(([labels_train],[labels_test]))[0]
        # labels_testt = np.vstack(([],[]))
        # data_train = np.concatenate([AR_flat_train, nAR_flat_train])
        data_train = np.hstack(([AR_flat_train], [nAR_flat_train]))[0]
        # data_test = np.concatenate([AR_flat_test, nAR_flat_test])
        data_test = np.hstack(([AR_flat_test], [nAR_flat_test]))[0]
        # labels_train = np.concatenate([lAR_flat_train, lnAR_flat_train])
        # labels_test = np.concatenate([lAR_flat_test, lnAR_flat_test])
        # labels_train=np.vstack(([[1,0]] * (data_train.shape[1]),[[0,1]] * (data_train.shape[1])))
        # labels_test=np.vstack(([[1,0]] * (data_test.shape[1]),[[0,1]] * (data_test.shape[1])))

         # np.vstack(([np.ones(data_train.shape)],[np.zeros(data_train.shape)],[np.ones(data_train.shape)]))


        # ([[np.ones(data_train.shape[1])], [np.zeros(data_train.shape[1])]])

        # np.array([[np.ones(data_train.shape[1])], [np.zeros(data_train.shape[1])]]).shape


        # labels_testt = np.vstack(([],[]))

        # data_train = np.random.rand(10000, 3072)
        #
        # data_test = np.random.rand(10000, 3072)

        self.inputs = {'train': normalize(data_train),
                       'test': normalize(data_test),
                       'validation': None}

        self.targets = {'train': labels_trainn,
                        'test': labels_trainn,
                        'validation': None}

        # def normalize(x):
        #     """Make each column mean zero, variance 1"""
        #     x -= np.mean(x, axis=0)
        #     x /= np.std(x, axis=0)

#             x = np.random.rand(1000)*10
# norm1 = x / np.linalg.norm(x)
# norm2 = normalize(x[:,np.newaxis], axis=0).ravel()
# print np.all(norm1 == norm2)

        # map(normalize, [self.inputs['train'], self.inputs['test']])

        self.format()



# hdf5_file = "/global/project/projectdirs/nervana/jusk/atmosphericriver_MC.h5"
# f = h5py.File(hdf5_file, 'r')
#
# AR = f['AR']
# nAR = f['Non_AR']
#
# shape_AR = AR.shape
# shape_nAR = nAR.shape
#
# AR_data = np.array(AR.value)
# nAR_data = np.array(nAR.value)



