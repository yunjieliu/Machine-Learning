
import numpy as np
import neon.util.persist
from neon.util.persist import deserialize
import cPickle
import pickle

def unpickle(file):
    # import cPickle
    fo = open(file, 'rb')
    dict = cPickle.load(fo)
    fo.close()
    return dict

f = "/Users/DOE6903584/Downloads/cifar-10-batches-py/data_batch_1"
nclasses = 10

def load_file(filename, nclasses):
    # logger.info('loading: %s', filename)
    dict = deserialize(filename)

    full_image = np.float32(dict['data'])
    full_image /= 255.

    # if self.dist_flag:
    #     read corresponding 'quad'rant of the image
        # data = full_image[:, self.dist_indices]
    # else:
    data = full_image

    labels = np.array(dict['labels'])
    onehot = np.zeros((len(labels), nclasses), dtype='float32')
    for col in range(nclasses):
        onehot[:, col] = (labels == col)
    return (data, onehot)

data, labels = load_file(f, nclasses)
#
# labels = np.array(dict['labels'])
# onehot = np.zeros((len(labels), nclasses), dtype='float32')

# for col in range(nclasses):
#     onehot[:, col] = (labels == col)
#     return (data, onehot)

# data, labels = load_file(filename, nclasses)
ncols = 32 * 32 * 3
inputs_test = np.zeros((data.shape[0], ncols),
                               dtype='float32')
targets_test = np.zeros((data.shape[0], nclasses),
                                dtype='float32')
inputs_test[:] = data
targets_test[:] = labels