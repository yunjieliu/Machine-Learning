#
#
import logging
import numpy as np
import h5py
import os
# import neon
#
from neon.datasets.dataset import Dataset
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
import ipdb
import sys
#
class AR(Dataset):

    # def __init__(self, **kwargs):
    #     self.__dict__.update(kwargs)

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        # if 'repo_path' not in kwargs:
        #     raise ValueError('Missing repo_path.')

        # self.rootdir = os.path.join(self.repo_path, self.__class__.__name__)
        # self.rootdir = self.repo_path

    def load(self):

        f = h5py.File(os.path.join(self.repo_path, self.hdf5_file), 'r')
        # f = h5py.File(os.path.join(self.rootdir, self.hdf5_file), 'r')

        AR = f['AR']
        nAR = f['Non_AR']


        tr = self.training_size
        te = self.test_size

        AR_data = np.vstack(AR.value)
        nAR_data = np.vstack(nAR.value)

        # labels = np.array(['AR', 'nAR'],dtype='|S3')

        # 35392 comes fropm shape np.zeros([158,224]).flatten()

        AR_train = AR_data[:tr]
        nAR_train = nAR_data[:tr]

        AR_test = AR_data[tr:tr+te]
        nAR_test = nAR_data[tr:tr+te]

        AR_flat_train = np.zeros([AR_train.shape[0], 35392])
        nAR_flat_train = np.zeros([nAR_train.shape[0], 35392])
        AR_flat_test = np.zeros([AR_test.shape[0], 35392])
        nAR_flat_test = np.zeros([nAR_test.shape[0], 35392])

        for ij in range(0,AR_train.shape[0]):
            AR_flat_train[ij] = AR_train[ij].flatten()
            nAR_flat_train[ij] = nAR_train[ij].flatten()
            # print(ij)

        for ij in range(0,AR_test.shape[0]):
            AR_flat_test[ij] = AR_test[ij].flatten()
            nAR_flat_test[ij] = nAR_test[ij].flatten()

        # data_train = np.concatenate([AR_flat_train, nAR_flat_train])
        data_train = np.vstack(([AR_flat_train], [nAR_flat_train]))
        # data_test = np.concatenate([AR_flat_test, nAR_flat_test])
        data_test = np.vstack(([AR_flat_test], [nAR_flat_test]))
        # labels_train = np.concatenate([lAR_flat_train, lnAR_flat_train])
        # labels_test = np.concatenate([lAR_flat_test, lnAR_flat_test])
        labels_train=np.vstack(([[1,0]] * (data_train.shape[1]),[[0,1]] * (data_train.shape[1])))
        labels_test=np.vstack(([[1,0]] * (data_test.shape[1]),[[0,1]] * (data_test.shape[1])))

        # ipdb.set_trace()
        f.close()

        self.targets['train'] = labels_train
        self.targets['test'] = labels_test

        self.inputs['train'] = data_train
        self.inputs['test'] = data_test

        dims = np.prod(self.inputs['train'].shape[-2:])
        self.inputs['train'].shape = (-1, dims)
        self.inputs['test'].shape = (-1, dims)

        # u
        # sys.stdout(repr(self.inputs['train'].shape))
        # print(self.inputs['train'].shape)
        # self.inputs['train'].shape = (-1, dims)
        # self.inputs['test'].shape = (-1, dims)

        # def normalize(x):
        #     """Make each column mean zero, variance 1"""
        #     x -= np.mean(x, axis=0)
        #     x /= np.std(x, axis=0)
        #
        # map(normalize, [self.inputs['train'], self.inputs['test']])

        # self.inputs = {'train': data_train,
        #                'test': data_test,
        #                'validation': None}
        #
        # self.targets = {'train': labels_train,
        #                 'test': labels_test,
        #                 'validation': None}

        self.format()


