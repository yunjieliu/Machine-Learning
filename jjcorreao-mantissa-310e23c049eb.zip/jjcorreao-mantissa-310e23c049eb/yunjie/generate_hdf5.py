# this code is to generate HDF5 file from the PKL images 
# Initially taken from Amir with little modification to deal with AR patch and dimensions
# There might be some problem on HOW PKL images are stored in HDF???? different from Amir's HDF5

import logging
import numpy as np
import matplotlib.pyplot as plt
import glob
import pandas
import h5py
import ipdb
import os

#<codecell>
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

#<codecell>
class ar(object):

#<codecell>
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        if 'repo_path' not in kwargs:
            raise ValueError('Missing repo_path.')
        # location of pkl AR files and hdf5
        self.pkldir = "/global/project/projectdirs/mantissa/climate/Yunjie/ar_patch/new"
        #self.scratchdir = '/scratch2/scratchdirs/khosra/neon-data'
        #self.rootdir = os.path.join(self.scratchdir, self.__class__.__name__)        
#<codecell>
    def hdf5(self, maxsize, outfile):
        #Convert pickle files into a single HDF5 containing two datasets:
        # \1: atmospheric river      (-1, 1, 158, 192) with 1 prognostic variables, currently we have only one prognostic variable
        # \0: non-atmospheric river  (-1, 1, 158, 192) 
        # \2: land mask              (-1, 1, 158, 192)
        # get a list of files in the AR directory
        pf = glob.glob(os.path.join(self.pkldir, 'atmosphericriver*_ar_imgs.pkl'))
        nf = glob.glob(os.path.join(self.pkldir, 'atmosphericriver*_nonar_imgs.pkl'))
        lf = glob.glob(os.path.join(self.pkldir, 'landmask_imgs.pkl'))

        # create a dataset of (i, variable, rows, cols) for atmospheric river and non atmospheric river
        fname = os.path.join(self.pkldir, outfile)
        # hack to avoid issue of unclosed hdf5 file handle in ipython
        try: os.remove(fname)
        except: pass
        f = h5py.File(fname, 'w')
        shape = (1, 158, 192)
        blk = 10000   # block size

        # make datasets(group) for AR, Non_AR, Landmask and allow them to be extensible
        one = f.create_dataset('1', (blk,) + shape,dtype=np.float32,maxshape=((None,) + shape))
        zero = f.create_dataset('0', (blk,) + shape,dtype=np.float32,maxshape=((None,) + shape))
        two =f.create_dataset('2',(blk,)+shape,dtype=np.float32,maxshape=((None,) +shape))

        # prognostic variables are keys of 'p' below
        vs1 = ["TMQ"] #dict variable for AR. Non-AR patch
        vs2=  ["mask"]  # dict variable for land mask patch
#<codecell>
        def read_write(files, h5dset):
            print h5dset
            i = 0
            r = np.empty(shape, dtype=np.float32)
            if (h5dset== zero or h5dset==one):  #ar, non-ar
               for f in files:
                   logger.debug('Reading %s' %f)
                   p = pandas.read_pickle(f)
                   l = len(p[vs1[0]])
                   print("number of events  %d" %l)
                   # loop through AR instances
                   for j in range(l):
                        # loop through prognostic variables fo reach case
                        for v,k in zip(vs1, range(len(vs1))):
                            r[k]=p[v][j][:158,:192]
                        h5dset[i] = r
                        i += 1

                        #check block dimension
                        if i == maxsize: break
                        if i % 100 == 0:
                           logger.debug('%d' % i)
                        # resize hdf5 as necessary to make room for more rows
                        if i % blk == 0:
                           h5dset.resize(i+blk, axis=0)
                   if i ==maxsize: break

            if (h5dset ==two):  #land mask
                for f in files:
                    logger.debug('Reading %s' %f)
                    p=pandas.read_pickle(f)
                    l=len(p[vs2[0]])
                    print("number of events %d" %l)
                    #loop through land mask
                    for j in range(l):
                        for v,k in zip(vs2, range(len(vs2))):
                            r[k]=p[v][j][:158,:192]
                        h5dset[i] = r
                        i += 1
                        #check block dimension
                        if i == maxsize: break
                        if i % 100 == 0:
                            logger.debug('%d' % i)
                        # resize hdf5 as necessary to make room for more rows
                        if i % blk == 0:
                            h5dset.resize(i+blk, axis=0)
                    if i == maxsize: break

            # final resize
            h5dset.resize(i, axis=0)
            logger.debug('Wrote %d records in total.' % i)
        # write pkl to HDF5
        read_write(pf, one)
        read_write(nf, zero)
        read_write(lf, two)
        f.close()
#not sure what this is for
if __name__ == '__main__':
    import os

    # create HDF5 version of dataset
    p = "/global/project/projectdirs/mantissa/climate/Yunjie/ar_patch/new"
    h = ar(repo_path=p)
    h.hdf5(maxsize=1000000, outfile='atmosphericriver_all.h5')
                                                                                                                                                                           122,13        Bot
