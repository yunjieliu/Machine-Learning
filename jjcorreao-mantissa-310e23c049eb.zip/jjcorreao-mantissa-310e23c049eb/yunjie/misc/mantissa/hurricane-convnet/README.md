Running a convolutional net on hurricane patches

    neon hurricane_cnn_small.yaml

