Multilayer perceptron (MLP) and logistic regression examples:

    neon hurricane_cpu_mlp-simple.yaml



