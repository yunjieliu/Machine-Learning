#code here is to extract the land sea mask image of the AR bounding box((-180.0, 19.0; -120.0, 56.0)
# indicator for land is 0, indicator for ocean is 1.
# note the land mask is 0.25 degree, the CAM5.0 grid is suppose to be 0.25, but it is not????
#<codecell>
import os
import os.path as op
import numpy as np
import pandas as pd
import netCDF4 as cdf
import matplotlib 
matplotlib.use("agg")
from matplotlib.pyplot import *

#<codecell>
#specify the directory of the cam5 data
camdir="/global/project/projectdirs/mantissa/climate/Yunjie"
outdir="/global/project/projectdirs/mantissa/climate/Yunjie/ar_patch/new"
#define global grid of the land mask 
IJ=(768,1152) #lat, lon
I,J =IJ

# step size between grid points (in degrees)
dI = 180./I  #lat
dJ = 360./J    #lon

# grid locations
gI = np.arange(-90, 90, dI)  #lat  
gJ = np.arange(0, 360, dJ)   #lon

#define bounding box and grids location  I-bot=19.0N,I-top=56.0N,J-left=-180.0W,J-right=-120.0W
Ilow=19.0
Itop=56.0
Jleft=180.0
Jright=250.0  # convert to 0-360 scale

# define keys
# currently we only looking at integrated water vapor, later may need wind etc. so put "keys" here to make later code modifacation easier.
keys= ["mask"]

#<codecell>
def nearestindex(x,v):
    #this part of the code is addapted from sang's hurricane code
    r=np.searchsorted(v,x,"right")-1
    return r if np.linalg.norm(v[r]-x) <= np.linalg.norm(v[r+1]-x) else r+1

#<codecell>
#find the bounding box index (used for later slicing the patch )
latlow=nearestindex(Ilow,gI)
lattop=nearestindex(Itop,gI)
#latbound=(latlow,lattop)
lonleft=nearestindex(Jleft,gJ)
lonright=nearestindex(Jright,gJ)
#lonbound=(lonleft,lonright)

#<codecell>
def save_event(f,ev):
     # this part of the code addapted from sang's hurricane code
     import pickle
     with open(f, "wb") as fid:
          pickle.dump(ev,fid)

#<codecell>  
def  cut_box(d):#, time):               
     #this part of the code addapted from sang's hurricane code
     # the purpose is to slice the patch bounded by bounds
     imgs= []
     #for i in range(0, time): #note, range(a,b) results in (b-a) number instead of (b-a+1)
     x=d[0,0,slice(latlow,lattop),slice(lonleft,lonright)]
     imgs+=[x]
     return imgs

#<codecell>
# access data file
fc=op.join(camdir,"land-sea-mask-v2-regrid.nc")
print ("current working file is ...")
print(fc)
dat=cdf.Dataset(fc,'r')
#print dat.data_model
print ("variables in the data file are ...")
print dat.variables
#---------
#here to make sure the data format, extract and other behaviors are as we expected, print out some data to check
#print("check the dimension of TMQ data")
#dim=Val.shape
#if abs(dim[1]-768)==0 and abs(dim[2]-1152)==0: #768 by 1152 is the prior knowledge
#     print("check pass")
#-----------

#loop through time step (day) and  cut the patch
allimgs=dict([(k,[]) for k in keys])   #define it as dictionary 
for k in keys:
    dim=dat.variables[k].shape
    #timestep=1  # no iteration in the land mask file
    imgs=cut_box(dat.variables[k])#,timestep)
    allimgs[k]+=imgs

#save imags into pkl file
outfile=op.join(outdir,"landmask")
save_event(outfile+'_imgs.pkl',allimgs)
       
        
