#code here is to extract the integrated water vapor image of th AR bounding box((-180.0, 19.0; -120.0, 56.0)
#comparing to sang's code, this code is ugly; please feel free to make it prettier

#<codecell>
import os
import os.path as op
import numpy as np
import pandas as pd
import netCDF4 as cdf
import matplotlib 
matplotlib.use("agg")
from matplotlib.pyplot import *

#<codecell>
#specify the directory of the cam5 data
camdir="/global/project/projectdirs/m1248/suren_data/climate/cam5_tmq"
outdir="/global/project/projectdirs/mantissa/climate/Yunjie/ar_patch/new"
#define global grid of CAM5.0 output
IJ=(768,1152) #lat, lon
I,J =IJ

# step size between grid points (in degrees)
dI = 180./(I-1)  #lat
dJ = 360./J    #lon

# grid locations
gI = np.arange(-90, 90 + dI, dI)  #lat  
gJ = np.arange(0, 360, dJ)   #lon

#define bounding box and grids location  I-bot=19.0N,I-top=56.0N,J-left=-180.0W,J-right=-120.0W
Ilow=19.0
Itop=56.0
Jleft=180.0
Jright=250.0  # convert to 0-360 scale

# define keys
# currently we only looking at integrated water vapor, later may need wind etc. so put "keys" here to make later code modifacation easier.
keys= ["TMQ"]

#<codecell>
def nearestindex(x,v):
    #this part of the code is addapted from sang's hurricane code
    r=np.searchsorted(v,x,"right")-1
    return r if np.linalg.norm(v[r]-x) <= np.linalg.norm(v[r+1]-x) else r+1

#<codecell>
#find the bounding box index (used for later slicing the patch )
latlow=nearestindex(Ilow,gI)
lattop=nearestindex(Itop,gI)
#latbound=(latlow,lattop)
lonleft=nearestindex(Jleft,gJ)
lonright=nearestindex(Jright,gJ)
#lonbound=(lonleft,lonright)

#<codecell>
def save_event(f,ev):
     # this part of the code addapted from sang's hurricane code
     import pickle
     with open(f, "wb") as fid:
          pickle.dump(ev,fid)

#<codecell>  
def  cut_box(d, timea,timeb):               
     #this part of the code addapted from sang's hurricane code
     # the purpose is to slice the patch bounded by bounds
     ar_imgs= []
     nonar_imgs=[]
     for i in timea: 
         x=d[i,slice(latlow,lattop),slice(lonleft,lonright)]
         ar_imgs+=[x]
     for j in timeb:
         y=d[j,slice(latlow,lattop),slice(lonleft,lonright)]
         nonar_imgs+=[y]
     return [ar_imgs, nonar_imgs]

#<codecell>
# access data file

#first read in the detected AR dates
dfile=op.join(outdir,"cam5_0.25degree_ar_stats_mod.txt")
with open(dfile) as df:
     dates=df.readlines()
     newdates=dates[0].split()
print("total numner of detected AR events are %d" %len(newdates))
#then deal with cam5.0 output
for year in range(1979,2006):
    for month in range(1,13):
        fc=op.join(camdir,"TMQ_cam5_1_amip_run2.cam2.h1.%04d-%02d.nc" %(year,month))
            
        print ("current working file is ...")
        print(fc,"\n")
        dat=cdf.Dataset(fc,'r')
        #print dat.data_model
        #print ("variables in the data file are ...")
        #print dat.variables
        #---------
        #here to make sure the data format, extract and other behaviors are as we expected, print out some data to check
        #print("check the dimension of TMQ data")
        #dim=Val.shape
        #if abs(dim[1]-768)==0 and abs(dim[2]-1152)==0: #768 by 1152 is the prior knowledge
        #     print("check pass")
        #-----------

        #loop through time step (day) and  cut the patch
        ar_allimgs=dict([(k,[]) for k in keys])   #define it as dictionary 
        nonar_allimgs=dict([(k,[]) for k in keys])   #define it as dictionary         
        for k in keys:
            dim=dat.variables[k].shape
            timestep=dim[0]    #he number of days withint a month 
            #evaluate the AR day and non-AR day
            AR_day=list()
            Non_AR_day=list()
            for day in range(0,timestep):
                   dd="%04d-%02d-%02d" %(year,month,day+1)
                   for ddd in newdates:
                       if (dd==ddd): 
                           AR_day.append(day)
            print AR_day     #get ar day
            Non_AR_day=[i for i in range(0, timestep) if  i not in AR_day] #get non-ar day
            print Non_AR_day
            [ar_imgs, nonar_imgs]=cut_box(dat.variables[k],AR_day,Non_AR_day)
            ar_allimgs[k]+=ar_imgs
            nonar_allimgs[k]+=nonar_imgs

        #save imags into pkl file
        outfile=op.join(outdir,"atmosphericriver-%04d-%02d" %(year,month))
        if (ar_allimgs[k] != []): # if there is ar events, then write out
            save_event(outfile+'_ar_imgs.pkl',ar_allimgs)
        if (nonar_allimgs[k]!=[]):
            save_event(outfile+'_nonar_imgs.pkl',nonar_allimgs)
        
